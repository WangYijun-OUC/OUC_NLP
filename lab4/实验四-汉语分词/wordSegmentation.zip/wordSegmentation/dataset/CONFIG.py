# 基于字典的词典 语料库地址
word_dict_DatasetName = "../dataset/pku/words.txt"
# 基于trie的词典 语料库地址
base_trie_DatasetName = "../dataset/pku/words.txt"

